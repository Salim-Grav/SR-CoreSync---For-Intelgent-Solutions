=============================================================================
  S&R CORESYNC SOLUTIONS • OFFICIAL BRAND IDENTITY GUIDELINES
  LUMINA CAFÉ MASTER ASSET SPECIFICATIONS
=============================================================================

PROJECT METADATA:
  • Brand Name: LUMINA CAFÉ
  • Subtitle: Artisan Coffee Roastery & Eco Packaging Architecture
  • Client: Lumina Coffee Roasters BV Amsterdam
  • Release Year: 2025
  • Verification Status: S&R Certified Authentic Vector Artwork

COLOR PALETTE SPECIFICATIONS:
  1. Primary Accent:    #c5a880 (Pantone Matching Equivalent)
  2. Signature Gold:    #3e2723
  3. Digital Glow:      #10b981
  4. Deep Contrast:     #0e0b08

APPROVED CLEAR SPACE & MINIMUM DIMENSIONS:
  • Digital Screens: Minimum 120px width @ 72 DPI
  • High-Resolution Print: Minimum 25mm width @ 300 DPI
  • Clear Zone: Keep minimum 1.5x emblem height clearance on all sides

OFFICIAL FILE FORMATS INCLUDED:
  • SVG/ : Scalable Vector Graphics for Responsive Web & Flutter / React Native
  • PNG-4K/ : 300 DPI Alpha Transparent Master Visuals
  • EPS/ : Industrial Vector format for Screen Printing, Signage & CNC Engraving
  • PDF-Guidelines/ : This Design Specification Sheet

LEGAL & COPYRIGHT:
  © 2025 Lumina Coffee Roasters BV Amsterdam. Designed & Engineered by S&R CoreSync Solutions.
  All Rights Reserved. Official Digital Release.
=============================================================================