=============================================================================
  S&R CORESYNC SOLUTIONS • OFFICIAL BRAND IDENTITY GUIDELINES
  TONEH MASTER ASSET SPECIFICATIONS
=============================================================================

PROJECT METADATA:
  • Brand Name: TONEH
  • Subtitle: Digital-First Streaming Media & Bilingual Typography Brand
  • Client: Toneh Media Group Dubai
  • Release Year: 2023
  • Verification Status: S&R Certified Authentic Vector Artwork

COLOR PALETTE SPECIFICATIONS:
  1. Primary Accent:    #6366f1 (Pantone Matching Equivalent)
  2. Signature Gold:    #c5a880
  3. Digital Glow:      #ec4899
  4. Deep Contrast:     #070913

APPROVED CLEAR SPACE & MINIMUM DIMENSIONS:
  • Digital Screens: Minimum 120px width @ 72 DPI
  • High-Resolution Print: Minimum 25mm width @ 300 DPI
  • Clear Zone: Keep minimum 1.5x emblem height clearance on all sides

OFFICIAL FILE FORMATS INCLUDED:
  • SVG/ : Scalable Vector Graphics for Responsive Web & Flutter / React Native
  • PNG-4K/ : 300 DPI Alpha Transparent Master Visuals
  • EPS/ : Industrial Vector format for Screen Printing, Signage & CNC Engraving
  • PDF-Guidelines/ : This Design Specification Sheet

LEGAL & COPYRIGHT:
  © 2023 Toneh Media Group Dubai. Designed & Engineered by S&R CoreSync Solutions.
  All Rights Reserved. Official Digital Release.
=============================================================================