=============================================================================
  S&R CORESYNC SOLUTIONS • OFFICIAL BRAND IDENTITY GUIDELINES
  SARLOR MASTER ASSET SPECIFICATIONS
=============================================================================

PROJECT METADATA:
  • Brand Name: SARLOR
  • Subtitle: Fatayer & Mana'ish • Artisanal Syrian Eatery
  • Client: SARLOR Restaurant Netherlands
  • Release Year: 2024
  • Verification Status: S&R Certified Authentic Vector Artwork

COLOR PALETTE SPECIFICATIONS:
  1. Primary Accent:    #c82333 (Pantone Matching Equivalent)
  2. Signature Gold:    #c5a880
  3. Digital Glow:      #f9d342
  4. Deep Contrast:     #0a0d0c

APPROVED CLEAR SPACE & MINIMUM DIMENSIONS:
  • Digital Screens: Minimum 120px width @ 72 DPI
  • High-Resolution Print: Minimum 25mm width @ 300 DPI
  • Clear Zone: Keep minimum 1.5x emblem height clearance on all sides

OFFICIAL FILE FORMATS INCLUDED:
  • SVG/ : Scalable Vector Graphics for Responsive Web & Flutter / React Native
  • PNG-4K/ : 300 DPI Alpha Transparent Master Visuals
  • EPS/ : Industrial Vector format for Screen Printing, Signage & CNC Engraving
  • PDF-Guidelines/ : This Design Specification Sheet

LEGAL & COPYRIGHT:
  © 2024 SARLOR Restaurant Netherlands. Designed & Engineered by S&R CoreSync Solutions.
  All Rights Reserved. Official Digital Release.
=============================================================================